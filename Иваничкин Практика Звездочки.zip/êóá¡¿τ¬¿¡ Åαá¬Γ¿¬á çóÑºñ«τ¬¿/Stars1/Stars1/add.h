#pragma once
#ifndef ADD_H
#define ADD_H

void InputArray(int n, int m, int* M, int** a);
int Random(int number, int number1);
void OutArray(int n, int index_star_n, int index_star_m, int* M, int** a);
void Memr(int n, int* �, int** a);

#endif